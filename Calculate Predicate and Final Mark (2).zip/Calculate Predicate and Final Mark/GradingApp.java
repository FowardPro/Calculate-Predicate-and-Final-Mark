public class GradingApp
{
public static void main(String[] args)
{
 MarksGradeFrame gui=new MarksGradeFrame();
 gui.setVisible(true);
}
}