
import java.awt.*;
import javax.swing.border.*;
import javax.swing.*;
import java.awt.event.*;
public class MarksGradeFrame extends JFrame {
        public MarksGradeFrame() {
        runFrame();
		}
		public void runFrame()
		{
        //create panels
        hgPnl = new JPanel(new GridLayout(2, 1));
        hgPnl.setBorder(new SoftBevelBorder(SoftBevelBorder.LOWERED));
        head1Pnl = new JPanel(new FlowLayout(FlowLayout.CENTER));
        subPnl = new JPanel(new FlowLayout(FlowLayout.CENTER));
        subPnl2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        marksPnl = new JPanel(new GridLayout(4, 1, 20, 20));

        firstLineMarkPnl = new JPanel(new GridLayout(1, 6, 1, 1));
        secondLineMarkPnl = new JPanel(new GridLayout(1, 6, 1, 1));
        lastCollectionPnl = new JPanel(new GridLayout(1, 2, 1, 1));
        predicatel1 = new JTextArea(10, 55);
        predicatel1.setEditable(false);
        predicatel1.setBorder(new SoftBevelBorder(SoftBevelBorder.LOWERED));
        examPnl = new JPanel(new FlowLayout(FlowLayout.CENTER));

        finalTF = new JTextArea(7, 22);
        finalTF.setEditable(false);
        finalTF.setBorder(new SoftBevelBorder(SoftBevelBorder.LOWERED));
        headingClientCombinedPnl = new JPanel(new BorderLayout());
        myMainComponent = new JPanel(new BorderLayout());

        //create labels
        H1 = new JLabel("DEVELOPMENT SOFTWARE 1B");
        H1.setLayout(new FlowLayout(FlowLayout.CENTER));
        H1.setFont(new Font(Font.DIALOG_INPUT, +Font.BOLD, 23));
        H2 = new JLabel("Calculation of Predicate and possible final mark");
        H3 = new JLabel("Please enter the following marks as a % in order to calculate the predicate:");
        H2.setLayout(new FlowLayout(FlowLayout.CENTER));
        H3.setLayout(new FlowLayout(FlowLayout.CENTER));
        H2.setFont(new Font(Font.DIALOG_INPUT, Font.ITALIC + Font.BOLD, 18));
        H3.setFont(new Font(Font.DIALOG_INPUT, Font.ITALIC + Font.BOLD, 14));
        head1Pnl.add(H1);
        subPnl.add(H2);
        subPnl2.add(H3);

        CTLbl1 = new JLabel("Class Test 1:");
        CTLbl2 = new JLabel("Class Test 2:");
        CTest3 = new JLabel("Class Test 3:");
        CTest4 = new JLabel("Class Test 4:");
        ST1 = new JLabel("Semester Test 1:");
        ST2 = new JLabel("Semester Test 2:");
        examMarkLbl = new JLabel("Final Mark:");
        examMarkLblSt = new JLabel("");
        //create textfields
        CTtest1txF = new JTextField(3);
        CTest2txF = new JTextField(3);
        CTest3txF = new JTextField(3);
        CTest4txF = new JTextField(3);
        STest1txF = new JTextField(3);
        STest2txF = new JTextField(3);
        examMarkFld = new JTextField(6);
        examMarkFld.setPreferredSize(new Dimension(10, 40));
        finalMarkPnl = new JPanel(new GridLayout(3, 2, 2, 7));
        //create buttons 
        calPnl=new JPanel(new FlowLayout(FlowLayout.CENTER));
        nextPnl=new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        calculateBtn = new JButton("Calculate");
        calculateBtn.addActionListener(new CalculateBtnListener());
        calculateBtn.setPreferredSize(new Dimension(130,30));
        nextStudent = new JButton("Next Student");
        nextStudent.addActionListener(new nextBtnListener());
        nextStudent.setPreferredSize(new Dimension(130,30));
        APnl1=new JPanel(new FlowLayout(FlowLayout.CENTER));
        APnl2=new JPanel(new FlowLayout(FlowLayout.CENTER));
        predicatel1.setBackground(Color.getColor("Light blue"));
        finalTF.setBackground(Color.getColor("Light blue"));
        //add components to panels
        hgPnl.add(head1Pnl); 
        hgPnl.add(subPnl);

        examPnl.add(examMarkLbl);

        examPnl.add(examMarkFld);
        firstLineMarkPnl.add(CTLbl1);
        
        firstLineMarkPnl.add(CTtest1txF);
        firstLineMarkPnl.add(CTest3);
        
        firstLineMarkPnl.add(CTest3txF);
        firstLineMarkPnl.add(ST1);
        
        firstLineMarkPnl.add(STest1txF);

        secondLineMarkPnl.add(CTLbl2);
        secondLineMarkPnl.add(CTest2txF);
        secondLineMarkPnl.add(CTest4);
        secondLineMarkPnl.add(CTest4txF);
        secondLineMarkPnl.add(ST2);
        secondLineMarkPnl.add(STest2txF);
        marksPnl.add(subPnl2); 
        marksPnl.add(firstLineMarkPnl); 
        marksPnl.add(secondLineMarkPnl);
        finalMarkPnl.add(examPnl);
        calPnl.add(calculateBtn);
        nextPnl.add(nextStudent);
        finalMarkPnl.add(calPnl);
        finalMarkPnl.add(nextPnl);
        headingClientCombinedPnl.add(hgPnl, BorderLayout.NORTH);
        headingClientCombinedPnl.add(marksPnl, BorderLayout.CENTER);
        lastCollectionPnl.add(finalMarkPnl);
        APnl2.add(finalTF);
        lastCollectionPnl.add(APnl2);
        APnl1.add(predicatel1);
        myMainComponent.add(headingClientCombinedPnl, BorderLayout.NORTH);
        myMainComponent.add(APnl1, BorderLayout.CENTER);
        myMainComponent.add(lastCollectionPnl, BorderLayout.SOUTH);
        add(myMainComponent);
        setResizable(false);
        setVisible(true);
        setTitle("Assignment");
        setSize(705, 660);
        setDefaultLookAndFeelDecorated(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setBounds(600, 160, 710, 660);
    }

    private class nextBtnListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            clearFields();
        }
    }

    private class CalculateBtnListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                double semesterTestSum = 0;
                // Calculate the sum of semester test percentages
                semesterTestSum = Double.parseDouble(STest1txF.getText());
                semesterTestSum += Double.parseDouble(STest2txF.getText());

                // Calculate Predicate Mark
                double predicateMark;
                predicateMark = (0.1 * (Double.parseDouble(CTtest1txF.getText())+Double.parseDouble(CTest2txF.getText())+Double.parseDouble(CTest3txF.getText())+Double.parseDouble(CTest4txF.getText()))) + (0.3 * semesterTestSum);

                if (predicateMark < 40) {
                    examMarkFld.setText("0");
                    predicatel1.setText("Predicate: " + predicateMark);
                    finalTF.setText("You do now qualify to write exam");
                } else {
                    // If Predicate Mark is 40 or more, display Final Mark
                    predicatel1.setText(predicateMark + "");
                    double finalMark = (predicateMark + Double.parseDouble(examMarkFld.getText())) / 2;
                    finalTF.setText("Final Mark: " + finalMark);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }
        }
    }
    public void clearFields()
    {
            CTtest1txF.setText("");
            CTest2txF.setText("");
            CTest3txF.setText("");
            STest2txF.setText("");
            predicatel1.setText("");
            finalTF.setText("");
            CTest4txF.setText("");
            STest1txF.setText("");
            examMarkLblSt.setText("");
            examMarkFld.setText("");
            
    }
    private JPanel hgPnl;
    private JPanel head1Pnl;
    private JPanel subPnl;
    private JPanel subPnl2;
    private JPanel marksPnl;
    private JPanel firstLineMarkPnl;
    private JPanel secondLineMarkPnl;
    private JPanel lastCollectionPnl;
    private JPanel finalMarkPnl;
    private JPanel examPnl;
    private JPanel calPnl;
    private JPanel nextPnl;
    private JPanel headingClientCombinedPnl;
    private JPanel myMainComponent;
    private JPanel APnl1;
    private JPanel APnl2;

    //labels
    private JLabel H1, H2,H3;
    private JLabel CTLbl1;
    private JLabel CTLbl2;
    private JLabel CTest3;
    private JLabel CTest4;
    private JLabel ST1;
    private JLabel ST2;
    private JLabel Em;
    private JLabel examMarkLbl;
    private JLabel examMarkLblSt;
    //textfields
    private JTextField CTtest1txF;
    private JTextField CTest2txF;
    private JTextField CTest3txF;
    private JTextField CTest4txF;
    private JTextField STest1txF;
    private JTextField STest2txF;
    private JTextField examMarkFld;
    //private button
    private JButton calculateBtn;
    private JButton nextStudent;

    private JTextArea predicatel1;
    private JTextArea finalTF;

}
